# picolo
Image-reading crate for transposing an image into its bareboned data
